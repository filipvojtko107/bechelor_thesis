+++
title = "toml.hpp"
type  = "docs"
+++

# toml.hpp

`toml.hpp` includes all other headers.

This allows access to all features of toml11.

This header file and `toml_fwd.hpp` are located under `${TOML11_INCLUDE_DIR}/`,
while other header files are located under `${toml11_include_dir}/toml11/`.
