#ifndef TOML11_SYNTAX_HPP
#define TOML11_SYNTAX_HPP

#include "fwd/syntax_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/syntax_impl.hpp" // IWYU pragma: export
#endif

#endif// TOML11_SYNTAX_HPP
